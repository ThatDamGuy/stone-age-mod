# Useless mod... Or is it?
Yeah, not a complicated mod. But some stuff will change your life. No joke.

## Importing

Simply download this repository as a zip, then import it through the `Mods` dialog in Mindustry. Or, unzip this repo inside Mindustry's `mods/` folder.

## Contributing

Do whatever you want with this. Idc. Just don't grief, would be nice.
